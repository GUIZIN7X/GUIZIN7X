import discord
from discord import ui, app_commands
from discord.ext import commands
import asyncio
import io
import os
import logging
from datetime import datetime

# ---------- CONFIG ----------
STAFF_ROLE_ID = 1434393176952541362
TRANSCRIPT_CHANNEL_ID = 1434397713310679231
TICKET_CATEGORY_OPEN_ID = 1434393178160496782
TICKET_CATEGORY_CLAIMED_ID = 1434393178160496782

# Canal onde as avaliações serão enviadas (você informou este ID)
FEEDBACK_CHANNEL_ID = 1434393178160496781

THUMBNAIL_ICON_URL = "https://cdn.discordapp.com/attachments/1434393178160496787/1434396081785016370/file_00000000ef90720e88083b707ba44498.png"
BANNER_IMAGE_URL = THUMBNAIL_ICON_URL

TICKET_COUNT_FILE = "ticket_count.txt"

# Tema visual 7X STUDIO: preto + roxo tech (usado em cores embed e textos)
THEME_COLOR = discord.Color.from_rgb(111, 0, 255)  # roxo vibrante

# ---------- UTIL ----------
def get_next_ticket_number():
    if not os.path.exists(TICKET_COUNT_FILE):
        with open(TICKET_COUNT_FILE, "w") as f:
            f.write("0")
        return 1
    with open(TICKET_COUNT_FILE, "r") as f:
        try:
            return int(f.read()) + 1
        except ValueError:
            return 1

def save_next_ticket_number(number):
    with open(TICKET_COUNT_FILE, "w") as f:
        f.write(str(number))

# ---------- RATING (Modal + View) ----------
class RatingModal(ui.Modal, title="Avaliação do Ticket"):
    comment = ui.TextInput(label="Comentário (opcional)", required=False, style=discord.TextStyle.paragraph, max_length=1000, placeholder="Conte-nos como foi o atendimento...")

    def __init__(self, ticket_id: str, rating: int):
        super().__init__()
        self.ticket_id = ticket_id
        self.rating = rating

    async def on_submit(self, interaction: discord.Interaction):
        # Enviar avaliação ao canal de feedback
        try:
            feedback_channel = interaction.client.get_channel(FEEDBACK_CHANNEL_ID)
            if feedback_channel:
                stars = "⭐" * self.rating + ("☆" * (5 - self.rating))
                embed = discord.Embed(
                    title=f"Avaliação - Ticket {self.ticket_id}",
                    description=f"**Avaliação:** {stars} ({self.rating}/5)",
                    color=THEME_COLOR,
                    timestamp=discord.utils.utcnow()
                )
                embed.add_field(name="Usuário", value=f"{interaction.user.mention} — `{interaction.user}`", inline=False)
                if self.comment.value:
                    embed.add_field(name="Comentário", value=self.comment.value, inline=False)
                embed.set_footer(text="7X STUDIO | Serviços em Geral")
                await feedback_channel.send(embed=embed)
            else:
                logging.error(f"Canal de feedback (ID: {FEEDBACK_CHANNEL_ID}) não encontrado.")
        except Exception:
            logging.exception("Erro ao enviar avaliação ao canal de feedback.")

        # Agradecer usuário (resposta ao modal)
        try:
            await interaction.response.send_message("Obrigado pela sua avaliação! 💜", ephemeral=True)
        except Exception:
            # fallback: enviar DM (caso a resposta tenha falhado por algum motivo)
            try:
                await interaction.user.send("Obrigado pela sua avaliação! 💜")
            except Exception:
                logging.warning("Não foi possível confirmar agradecimento ao usuário (DM/resposta).")

class RatingView(ui.View):
    def __init__(self, ticket_id: str, timeout: float | None = None):
        super().__init__(timeout=timeout)
        self.ticket_id = ticket_id

    @ui.button(label="1", style=discord.ButtonStyle.secondary, custom_id="rate_1")
    async def rate_1(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.send_modal(RatingModal(self.ticket_id, 1))

    @ui.button(label="2", style=discord.ButtonStyle.secondary, custom_id="rate_2")
    async def rate_2(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.send_modal(RatingModal(self.ticket_id, 2))

    @ui.button(label="3", style=discord.ButtonStyle.secondary, custom_id="rate_3")
    async def rate_3(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.send_modal(RatingModal(self.ticket_id, 3))

    @ui.button(label="4", style=discord.ButtonStyle.primary, custom_id="rate_4")
    async def rate_4(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.send_modal(RatingModal(self.ticket_id, 4))

    @ui.button(label="5", style=discord.ButtonStyle.success, custom_id="rate_5")
    async def rate_5(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.send_modal(RatingModal(self.ticket_id, 5))

# ---------- TICKET ACTIONS ----------
class TicketActionsView(ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    async def check_if_claimed(self, interaction: discord.Interaction):
        async for message in interaction.channel.history(limit=1, oldest_first=True):
            if message.embeds:
                embed = message.embeds[0]
                return any(field.name == "Ticket Assumido Por" for field in embed.fields)
        return False

    @ui.button(label="Fechar Ticket", style=discord.ButtonStyle.danger, custom_id="close_ticket_final_v22", emoji="❌")
    async def close_ticket_button(self, interaction: discord.Interaction, button: ui.Button):
        logging.info(f"'{interaction.user.name}' iniciou o processo para fechar o ticket '{interaction.channel.name}'.")
        await interaction.response.defer()
        staff_role = interaction.guild.get_role(STAFF_ROLE_ID)
        transcript_channel = interaction.guild.get_channel(TRANSCRIPT_CHANNEL_ID)
        if staff_role not in interaction.user.roles:
            await interaction.followup.send("❌ Apenas membros da equipe podem fechar tickets.", ephemeral=True)
            return
        if not transcript_channel:
            logging.error(f"Canal de transcript (ID: {TRANSCRIPT_CHANNEL_ID}) não foi encontrado.")
            await interaction.followup.send("ERRO: Canal de transcripts não configurado.", ephemeral=True)
            return

        countdown_message = await interaction.followup.send("A guardar o transcript...")

        try:
            topic_parts = interaction.channel.topic.split(" | ")
            ticket_id_str = topic_parts[0].replace("Ticket ID: ", "")
            user_id_str = topic_parts[1].replace("Aberto por: ", "")
            ticket_owner = await interaction.guild.fetch_member(int(user_id_str))

            # Collect messages
            messages = [msg async for msg in interaction.channel.history(limit=None, oldest_first=True)]
            transcript_content = f"--- Transcript do Ticket {ticket_id_str} ---\n"
            transcript_content += f"Aberto por: {ticket_owner.display_name} ({ticket_owner.id})\n"
            transcript_content += f"Fechado por: {interaction.user.display_name} ({interaction.user.id})\n"
            transcript_content += "-"*50 + "\n\n"
            for msg in messages:
                timestamp = msg.created_at.strftime("%d/%m/%Y às %H:%M:%S")
                line = f"[{timestamp}] {msg.author.display_name}: {msg.clean_content}\n"
                transcript_content += line
                if msg.attachments:
                    for attachment in msg.attachments:
                        transcript_content += f"  [Anexo: {attachment.url}]\n"

            # Send transcript to log channel
            transcript_file = discord.File(io.StringIO(transcript_content), filename=f"transcript-{interaction.channel.name}.txt")
            log_embed = discord.Embed(title=f"Transcript do Ticket {ticket_id_str}", color=discord.Color.orange(), timestamp=discord.utils.utcnow())
            log_embed.add_field(name="Aberto Por", value=ticket_owner.mention, inline=True)
            log_embed.add_field(name="Fechado Por", value=interaction.user.mention, inline=True)
            log_embed.set_footer(text=f"© {interaction.guild.name}. All rights reserved.", icon_url=interaction.guild.icon.url if interaction.guild.icon else None)
            await transcript_channel.send(embed=log_embed, file=transcript_file)
            logging.info(f"Transcript do ticket {ticket_id_str} enviado para o canal de logs.")

            # Try sending transcript via DM
            transcript_file_for_dm = discord.File(io.StringIO(transcript_content), filename=f"transcript-{interaction.channel.name}.txt")
            try:
                dm_embed = discord.Embed(
                    title="O seu ticket de suporte foi fechado",
                    description=f"Olá! O seu ticket `{ticket_id_str}` foi fechado. Em anexo, encontra um registo completo da conversa.",
                    color=discord.Color.blue()
                )
                dm_embed.set_footer(text=f"© {interaction.guild.name}. All rights reserved.", icon_url=interaction.guild.icon.url if interaction.guild.icon else None)
                await ticket_owner.send(embed=dm_embed, file=transcript_file_for_dm)
            except discord.Forbidden:
                logging.warning(f"Não foi possível enviar a DM do transcript para {ticket_owner.name} (DMs desativadas).")

            # Enviar pedido de avaliação por DM (com view de 1-5 estrelas + modal comentário)
            try:
                rating_embed = discord.Embed(
                    title="Avalie o atendimento",
                    description=(
                        "Obrigado por contatar o suporte da **7X STUDIO**.\n"
                        "Por favor, avalie o atendimento com **1–5 estrelas** e deixe um comentário opcional.\n\n"
                        "Clique no número correspondente à nota que deseja dar (1 = pior, 5 = excelente)."
                    ),
                    color=THEME_COLOR,
                    timestamp=discord.utils.utcnow()
                )
                rating_embed.set_footer(text=f"Ticket {ticket_id_str} • 7X STUDIO")
                await ticket_owner.send(embed=rating_embed, view=RatingView(ticket_id_str))
            except discord.Forbidden:
                logging.warning(f"Não foi possível enviar a solicitação de avaliação para {ticket_owner.name} (DMs desativadas).")

        except Exception:
            logging.exception("Ocorreu um erro ao criar e enviar o transcript.")
            await countdown_message.edit(content="Ocorreu um erro ao gerar o transcript. O ticket não será fechado.")
            return

        # Countdown visual antes de apagar canal
        for i in range(5, 0, -1):
            await countdown_message.edit(content=f"Transcript guardado. Este canal será apagado em **{i}**...")
            await asyncio.sleep(1)

        try:
            await interaction.channel.delete(reason=f"Ticket {ticket_id_str} fechado por {interaction.user.name}")
            logging.warning(f"Ticket '{interaction.channel.name}' foi fechado e apagado.")
        except discord.NotFound:
            pass

    @ui.button(label="Informações do Ticket", style=discord.ButtonStyle.secondary, custom_id="info_ticket_final_v22", emoji="ℹ️")
    async def info_ticket_button(self, interaction: discord.Interaction, button: ui.Button):
        logging.info(f"'{interaction.user.name}' pediu informações do ticket '{interaction.channel.name}'.")
        await interaction.response.defer(ephemeral=True)
        ticket_owner = None
        if interaction.channel.topic and "Aberto por" in interaction.channel.topic:
            try:
                user_id = int(interaction.channel.topic.split("Aberto por: ")[1])
                ticket_owner = await interaction.guild.fetch_member(user_id)
            except:
                ticket_owner = None
        claimed_by = "Ninguém ainda"
        message_count = 0
        async for message in interaction.channel.history(limit=None):
            message_count += 1
            if message.embeds and not claimed_by.startswith("<@"):
                for field in message.embeds[0].fields:
                    if field.name == "Ticket Assumido Por":
                        claimed_by = field.value
                        break
        info_embed = discord.Embed(title="Informações do Ticket", color=discord.Color.blue())
        info_embed.add_field(name="Criado Por", value=f"{ticket_owner.mention if ticket_owner else 'Usuário não encontrado'}", inline=True)
        info_embed.add_field(name="Assumido Por", value=claimed_by, inline=True)
        info_embed.add_field(name="Total de Mensagens", value=str(message_count), inline=True)
        if interaction.channel.created_at:
            info_embed.add_field(name="Aberto Em", value=f"<t:{int(interaction.channel.created_at.timestamp())}:F>", inline=False)
            info_embed.add_field(name="Aberto Há", value=f"<t:{int(interaction.channel.created_at.timestamp())}:R>", inline=False)
        info_embed.set_footer(text=f"© {interaction.guild.name}. All rights reserved.", icon_url=interaction.guild.icon.url if interaction.guild.icon else None)
        await interaction.followup.send(embed=info_embed, ephemeral=True)

    @ui.button(label="Assumir Ticket", style=discord.ButtonStyle.success, custom_id="claim_ticket_final_v22", emoji="🟢")
    async def claim_ticket_button(self, interaction: discord.Interaction, button: ui.Button):
        logging.info(f"'{interaction.user.name}' tentou assumir o ticket '{interaction.channel.name}'.")
        await interaction.response.defer()
        try:
            staff_role = interaction.guild.get_role(STAFF_ROLE_ID)
            if staff_role not in interaction.user.roles:
                await interaction.followup.send("❌ Apenas membros da equipe podem assumir tickets.", ephemeral=True)
                return
            if await self.check_if_claimed(interaction):
                await interaction.followup.send("❌ Este ticket já foi assumido.", ephemeral=True)
                return
            original_message = None
            async for message in interaction.channel.history(limit=1, oldest_first=True):
                original_message = message
                break
            if original_message and original_message.embeds:
                original_embed = original_message.embeds[0]
                original_embed.add_field(name="Ticket Assumido Por", value=interaction.user.mention, inline=False)
                button.disabled = True
                await original_message.edit(embed=original_embed, view=self)
                user_id = int(interaction.channel.topic.split("Aberto por: ")[1])
                ticket_owner = await interaction.guild.fetch_member(user_id)
                claimed_category = interaction.guild.get_channel(TICKET_CATEGORY_CLAIMED_ID)
                if claimed_category:
                    await interaction.channel.edit(name=f"🎟️・{ticket_owner.name}", category=claimed_category)
                logging.info(f"Ticket '{interaction.channel.name}' foi assumido com sucesso por '{interaction.user.name}'.")
                await interaction.followup.send(f"✅ Ticket assumido por {interaction.user.mention}!")
            else:
                await interaction.followup.send("Erro: Não foi possível encontrar a mensagem original do ticket.", ephemeral=True)
        except Exception:
            logging.exception("Ocorreu um erro no botão 'Assumir Ticket'.")
            await interaction.followup.send("Ocorreu um erro inesperado.", ephemeral=True)

# ---------- TICKET PANEL (com botões Compras / Parcerias / Suporte / Dúvidas) ----------
class TicketPanelView(ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    async def create_ticket(self, interaction: discord.Interaction, tipo: str):
        logging.info(f"'{interaction.user.name}' está a abrir um novo ticket ({tipo}).")
        await interaction.response.defer(ephemeral=True, thinking=True)

        user_id_str_check = f"Aberto por: {interaction.user.id}"
        categories_to_check = [
            interaction.guild.get_channel(TICKET_CATEGORY_OPEN_ID),
            interaction.guild.get_channel(TICKET_CATEGORY_CLAIMED_ID),
        ]

        for category in categories_to_check:
            if category:
                for channel in category.text_channels:
                    if channel.topic and user_id_str_check in channel.topic:
                        logging.warning(f"'{interaction.user.name}' tentou abrir um ticket, mas já tem um em {channel.mention}.")
                        await interaction.followup.send(f"❌ Você já possui um ticket aberto em {channel.mention}! Por favor, feche o antigo antes de abrir um novo.", ephemeral=True)
                        return

        ticket_number = get_next_ticket_number()
        ticket_id = f"#{str(ticket_number).zfill(4)}"
        save_next_ticket_number(ticket_number)
        staff_role = interaction.guild.get_role(STAFF_ROLE_ID)
        open_category = interaction.guild.get_channel(TICKET_CATEGORY_OPEN_ID)
        if not open_category:
            logging.error(f"A categoria para tickets abertos (ID: {TICKET_CATEGORY_OPEN_ID}) não foi encontrada.")
            await interaction.followup.send("ERRO: A categoria para tickets abertos não foi encontrada.", ephemeral=True)
            return

        overwrites = {
            interaction.guild.default_role: discord.PermissionOverwrite(read_messages=False),
            interaction.user: discord.PermissionOverwrite(read_messages=True, send_messages=True, attach_files=True),
            staff_role: discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_messages=True, attach_files=True)
        }
        try:
            channel_name = f"🎫・{interaction.user.name}"
            channel_topic = f"Ticket ID: {ticket_id} | Aberto por: {interaction.user.id}"
            ticket_channel = await interaction.guild.create_text_channel(
                name=channel_name, category=open_category, overwrites=overwrites, topic=channel_topic)
            logging.info(f"Ticket {ticket_id} criado para '{interaction.user.name}' no canal {ticket_channel.mention}.")
        except discord.Forbidden:
            logging.error("O bot não tem permissão para criar canais.")
            await interaction.followup.send("ERRO: O bot não tem permissão para criar canais.", ephemeral=True)
            return

        # Embedded welcome message (decorado, tema 7X STUDIO)
        welcome_embed = discord.Embed(
            title=f"🎫 Ticket {ticket_id} — {tipo}",
            description=(
                f"Olá {interaction.user.mention}! Obrigado por abrir um ticket com a **7X STUDIO**.\n\n"
                "Explique o seu pedido com o máximo de detalhe possível. Um membro da nossa equipe irá contactá-lo em breve."
            ),
            color=THEME_COLOR,
            timestamp=discord.utils.utcnow()
        )
        welcome_embed.add_field(name="Tipo", value=tipo, inline=True)
        welcome_embed.add_field(name="Como Ajudar", value="- Descreva o problema/serviço.\n- Envie prints, logs e links.\n- Seja específico com o que deseja.", inline=False)
        welcome_embed.set_thumbnail(url=THUMBNAIL_ICON_URL)
        welcome_embed.set_image(url=BANNER_IMAGE_URL)
        welcome_embed.set_footer(text="© 7X STUDIO | SERVIÇOS EM GERAL")

        await ticket_channel.send(content=f"{interaction.user.mention}", embed=welcome_embed, view=TicketActionsView())
        await interaction.followup.send(f"✅ Seu ticket foi criado com sucesso! Acesse-o em {ticket_channel.mention}", ephemeral=True)

    @ui.button(label="COMPRAS", style=discord.ButtonStyle.primary, custom_id="open_ticket_compras", emoji="🛒")
    async def compras_button(self, interaction: discord.Interaction, button: ui.Button):
        await self.create_ticket(interaction, "COMPRAS")

    @ui.button(label="PARCERIAS", style=discord.ButtonStyle.primary, custom_id="open_ticket_parcerias", emoji="🤝")
    async def parcerias_button(self, interaction: discord.Interaction, button: ui.Button):
        await self.create_ticket(interaction, "PARCERIAS")

    @ui.button(label="SUPORTE", style=discord.ButtonStyle.secondary, custom_id="open_ticket_suporte", emoji="🛠️")
    async def suporte_button(self, interaction: discord.Interaction, button: ui.Button):
        await self.create_ticket(interaction, "SUPORTE")

    @ui.button(label="DÚVIDAS", style=discord.ButtonStyle.secondary, custom_id="open_ticket_duvidas", emoji="❓")
    async def duvidas_button(self, interaction: discord.Interaction, button: ui.Button):
        await self.create_ticket(interaction, "DÚVIDAS")

# ---------- COG ----------
class TicketSystem(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        # Registra views persistentes (importante para bot reiniciado)
        self.bot.add_view(TicketPanelView())
        self.bot.add_view(TicketActionsView())
        # Não registra RatingView globalmente porque ele é criado dinamicamente com ticket_id quando envia o DM.
        # Se quiser persistência entre restarts para avaliações pendentes, adicione a persistência conforme necessidade.

    @app_commands.command(name="tickets", description="Mostra uma lista de todos os tickets atuais.")
    @app_commands.checks.has_role(STAFF_ROLE_ID)
    async def list_tickets(self, interaction: discord.Interaction):
        logging.info(f"O staff '{interaction.user.name}' usou o comando /tickets.")
        await interaction.response.defer(ephemeral=True)
        embed = discord.Embed(title="📋 Lista de Tickets Atuais", color=discord.Color.blurple(), timestamp=discord.utils.utcnow())

        open_category = interaction.guild.get_channel(TICKET_CATEGORY_OPEN_ID)
        claimed_category = interaction.guild.get_channel(TICKET_CATEGORY_CLAIMED_ID)

        open_tickets = [f"{ch.topic.split(' | ')[0].replace('Ticket ID: ', '')} ▸ {ch.mention}" for ch in open_category.text_channels if ch.topic and "Ticket ID" in ch.topic] if open_category else []
        claimed_tickets = [f"{ch.topic.split(' | ')[0].replace('Ticket ID: ', '')} ▸ {ch.mention}" for ch in claimed_category.text_channels if ch.topic and "Ticket ID" in ch.topic] if claimed_category else []

        embed.add_field(name=f"Abertos ({len(open_tickets)}) 🎫", value="\n".join(open_tickets) if open_tickets else "Nenhum", inline=False)
        embed.add_field(name=f"Assumidos ({len(claimed_tickets)}) 🎟️", value="\n".join(claimed_tickets) if claimed_tickets else "Nenhum", inline=False)

        await interaction.followup.send(embed=embed, ephemeral=True)

    @list_tickets.error
    async def on_list_tickets_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingRole):
            await interaction.response.send_message("❌ Você não tem o cargo `Staff` para usar este comando.", ephemeral=True)
        else:
            logging.error(f"Erro no comando /tickets: {error}")
            await interaction.response.send_message("Ocorreu um erro inesperado.", ephemeral=True)

    @app_commands.command(name="ticketsetup", description="Cria o painel de tickets.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def ticket_setup(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)

        embed = discord.Embed(
            title="🛡️ Suporte — 7X STUDIO",
            description="Obrigado por contatar o suporte! Selecione o tipo do seu pedido abaixo para abrir um ticket específico.\n\n"
                        "Escolha a opção correspondente: **COMPRAS**, **PARCERIAS**, **SUPORTE** ou **DÚVIDAS**.",
            color=discord.Color.from_rgb(20, 20, 20)
        )
        embed.add_field(name="No ticket, inclua:", value="- Descrição clara do problema.\n- Prints, logs ou provas relevantes.\n- Nomes dos envolvidos (se houver).\n- O que já tentou para resolver.", inline=False)
        embed.add_field(name="Processo:", value="- Um atendente analisará e responderá o mais rápido possível.\n- Podemos pedir mais informações.\n- Após solução, o ticket será fechado e você poderá avaliar o atendimento.", inline=False)
        embed.set_thumbnail(url=THUMBNAIL_ICON_URL)
        embed.set_image(url=BANNER_IMAGE_URL)
        embed.set_footer(text="© 7X STUDIO | TODOS DIREITOS RESERVADOS.")

        await interaction.channel.send(embed=embed, view=TicketPanelView())

    @ticket_setup.error
    async def on_ticket_setup_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message("❌ Você não tem permissão para usar este comando.", ephemeral=True)
        else:
            logging.error(f"Erro no comando /ticketsetup: {error}")
            await interaction.response.send_message("Ocorreu um erro inesperado.", ephemeral=True)

# ---------- SETUP ----------
async def setup(bot: commands.Bot):
    await bot.add_cog(TicketSystem(bot))